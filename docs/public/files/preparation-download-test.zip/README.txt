Preparation download test

Extract this ZIP and open download-success.txt.
The CSV contains three fictional service requests for file-access testing only.
This archive contains no executable code and does not install software.
